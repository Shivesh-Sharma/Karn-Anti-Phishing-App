package com.ayush.url_checker_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Location extends AppCompatActivity {

    EditText cgpa,iq,profile_score;
    Button predict;
    TextView result,result2,result3,result4;
    String url = "http://ec2-13-53-234-178.eu-north-1.compute.amazonaws.com:8080/location";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.location);
        cgpa = findViewById(R.id.url);
        predict = findViewById(R.id.predict);
        result = findViewById(R.id.result);
        result2 = findViewById(R.id.result2);
        result3 = findViewById(R.id.result3);
        result4 = findViewById(R.id.result4);
        Intent intent = getIntent();
        String cgpaValue = intent.getStringExtra("cgpa_value");
        cgpa.setText(cgpaValue);

        // Call the method to hit the API
        hitAPI();

    }

    // Method to hit the API
    private void hitAPI() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String data = jsonObject.getString("address");
                            String data2 = jsonObject.getString("ip_address");
                            String data3 = jsonObject.getString("latitude");
                            String data4 = jsonObject.getString("longitude");
                            result.setText("Address: "+data);
                            result2.setText("IP Address: "+data2);
                            result3.setText("Latitude: "+data3);
                            result4.setText("Longitude: "+data4);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Location.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String,String>();
                params.put("url",cgpa.getText().toString());


                return params;
            }

        };
        RequestQueue queue = Volley.newRequestQueue(Location.this);
        queue.add(stringRequest);
    }
}
