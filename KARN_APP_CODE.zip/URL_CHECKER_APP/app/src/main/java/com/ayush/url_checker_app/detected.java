package com.ayush.url_checker_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class detected extends AppCompatActivity {
    EditText cgpa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();

        setContentView(R.layout.phishing_detected);

        cgpa = findViewById(R.id.url);

        Button openNewScreenButton = findViewById(R.id.track);
        Intent intent = getIntent();
        String cgpaValue = intent.getStringExtra("cgpa_value");
        cgpa.setText(cgpaValue);

        openNewScreenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(detected.this, Location.class);
                intent.putExtra("cgpa_value", cgpa.getText().toString());
                startActivity(intent);
            }
        });
    }
}
